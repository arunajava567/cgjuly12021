package regex;
import java.util.StringTokenizer;
public class Stringtokendemo {
	public static void main(String[] args) {
		String s="Capgemini Whitefields Banglore Karnataka 500090";
		StringTokenizer st=new StringTokenizer(s,"-");
		System.out.println(st.countTokens());
		while(st.hasMoreTokens()) {
			System.out.println(st.nextToken());
			
		}
	}
}
