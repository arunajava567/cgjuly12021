public class IfElseCascade
{
		public static void main(String args[]) throws Exception
		{
				int i=0;

				char ch=' ';
				
				System.out.println("Enter an alphabet : ");

				
						ch = (char) System.in.read();
				
				

				if(ch=='a')
				{
						i = 10;
				}
				else if(ch=='b')
				   {
							i = 20;
				   }
				else if(ch=='c')
				   {
							i = 30;
				   }
				else if(ch=='d')
				   {
							i = 40;
				   }
				else
				 i=50;

				System.out.println("i Value is ...	:	" + i);
		}
}