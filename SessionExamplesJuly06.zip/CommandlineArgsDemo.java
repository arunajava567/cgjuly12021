
public class CommandlineArgsDemo {

	public static void main(String[] args) {
		
		System.out.println("Name:"+args[0]);
		System.out.println(("Address:"+args[1]));
		

	}

}
