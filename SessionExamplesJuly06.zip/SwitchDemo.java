//Switch Demo
public class SwitchDemo
{
     public static void main(String[] args) throws Exception 
     {
		java.util.Scanner in = new java.util.Scanner(System.in);
		System.out.println("enter any char(r,g,b,y,w...)");
		char c=(char)System.in.read();
		System.out.println("enter dept code");
		int d=in.nextInt();
		
		switch (c) 
		{
		case 'r' :{ System.out.println("Red"); break;}
		case 'g' :{ System.out.println("Green"); break;}
		case 'y' :{ System.out.println("Yellow"); break;}
		case 'b' :{ System.out.println("Blue"); break;}
		case 'w' :{ System.out.println("White"); break;}
		default : System.out.println("No colcor defined ....");
		
		
		}
		
		switch (d) 
		{
		case 10 :{ System.out.println("ADMIN"); break;}
		case 20 :{ System.out.println("Operations"); break;}
		case 30 :{ System.out.println("IT"); break;}
		case 40 :{ System.out.println("Networkig"); break;}
		case 50 :{ System.out.println("INFRA"); break;}
		default : System.out.println("No department defined ....");
		
		
		}
		/*
		System.out.println("Enter Number 1");
		int n1 = in.nextInt();
		
		System.out.println("Enter Number 2");
		int n2 = in.nextInt();
		
		System.out.println("1. Add Numbers");
		System.out.println("2. Subtract Numbers");
		System.out.println("3. Multiply Numbers");
		System.out.println("4. Divide Numbers");
		System.out.println("Enter your Choice");
		
		int choice = in.nextInt();
		
		switch(choice)
		{
			case 1 : result = n1 + n2;break;
			case 2 : result = n1 - n2;break;
			case 3 : result = n1 * n2;break;
			case 4 : result = n1 / n2;break;
			default: System.out.println("Invalid Choice");System.exit(1);
		}
		System.out.println("Result:"+result);
		
		*/
     }
}