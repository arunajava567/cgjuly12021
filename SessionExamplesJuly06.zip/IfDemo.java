import java.util.Scanner;

public class IfDemo {

	public static void main(String[] args) { // to read data at runtime 
		Scanner sc=new Scanner(System.in);//library  sc.nextInt()  ,sc.nextDouble(),sc.nextFloat()
		System.out.println(" enter any two numbers");
		int a=sc.nextInt();
		int b=sc.nextInt();
		
		if (a>0  && b>50 )
		      {  if    (a>b)
		            	System.out.println("a is big");
		          else 
		        	     System.out.println("b is big");
		     }
		
		
		//( a>b ) ? (a+" is big") : (b+"b is big");
  }
}
