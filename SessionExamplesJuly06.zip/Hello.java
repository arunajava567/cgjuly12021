
public class Hello {

  public static void main(String[] args) {
	  // static , final,if,for,while  
	  //byte-> short->int->float->long->double 
	  //char , boolean
	  int a=310;
	  int b=230;
	  int c=a+b;
	  double pi=3.142;
	  System.out.println("sum="+c);
	  
	  byte a1=20;
	  //byte to int   -> lower to higher -> upcasting ->implicit->narrowing
	  
	  int a11=a1;
	  //int to byte   -> hogher to lower ->downcasting ->explicit->widening
	  byte b1=(byte)b;
	  
	  
	  short a2=3434;
	  float a3=12321.213f;
	  long  a4=34543l;
	  double s5=234234324.123123;
	  
	  char x='@';  //'A'   ,'6'
	  boolean y=true;
	  System.out.println("welcome to Java programming in Eclipe");
	  
	  
  }
}
