package com.cg.ems;



import java.util.Scanner;

class Employee{
                //state of class , members of a class, member variable,data
     int id;
     String name;
     double sal;
     String dep;  
     Employee() { //initializing members of class
    	 id=100;
    	 name="RAM";
    	 sal=9898.99;
    	 dep="PF";
     }
                  //behaviour of class, member functions of class, methods
     void readEmpDetails() {
     Scanner sc=new Scanner(System.in);
     System.out.println("enter employee data  id ,name,sal,dep");
      id=sc.nextInt(); 
      sc.nextLine(); // to clear buffer
      name=sc.nextLine();
      sal=sc.nextDouble();
      sc.nextLine();// to clear buffer
       dep=sc.nextLine();
    }
    void dispEmpDetails() {

     System.out.println(" Id:"+id);
     System.out.println(" Name:"+name);
     System.out.println(" Salary:"+sal);
     System.out.println(" Department:"+dep);

   }
}