package com.cg.ems;

// java.lang
//java.util.
//java.sql
//java.io
//java.awt
//javax.net   -> java extension



import java.util.Scanner;
import java.util.Date;
import com.cg.pms.Product;
// client, test ,run
// class can be invoked  by other class
public class EmployeeTest {
	public static void main(String[] args) {
		
		Product p=new Product();
		
		// Object creation , instance of class, reference to class , pointre to class
		Employee e=new Employee();
		//accessing a variable of a class
		System.out.println(e.id+"  "+e.name+"  "+e.sal+"  "+e.dep);
	//	e.readEmpDetails();  // calling a function
		e.dispEmpDetails();  // method
		Employee e1=new Employee();
		/*e1.id=102;
		e1.name="ABC";
		e1.sal=2345.65;
		e1.dep="INFRA";
	*/
		//e1.readEmpDetails();  // calling a function
		e1.dispEmpDetails(); 
	//	Employee e2=new Employee();
		
		
	}
}
/*

Task :
	
	
	create a class Product with members id, name,qty,price(unit price),totalcost;

    create function readProductDEtaisl() -> input id,name,qty,price
    create function calcTotalPrice() ->  find total price qty*price
    create function to displayProductBillDetails() -> id,name,qty,unitprice,Totalprice
    create an object p and display bill for single produce.
    
    */









