package com.cg.pms;

public class InitializerDemo {
	//instance blocks are called before constructor
	{
		System.out.println("instance block1 ....before constructor ");
	}
	{
		System.out.println("instance block2 ....before constructor ");
	}
	//ananymous blocks  , called before main method 
	static {
		
		System.out.println(" entrypoint to my class before main block 1");
	}
	
	
	InitializerDemo() {
		System.out.println("  in constructor");
	}
	{
		System.out.println("instance block3 ....before constructor ");
	}
	
	//named blocks
	void show() {
		System.out.println("in show");
	}
  static {
		
		System.out.println(" entrypoint to my class before main block 2");
	}
	public static void main(String[] args) {
		System.out.println("main started");
		InitializerDemo i=new InitializerDemo();
		InitializerDemo i1=new InitializerDemo();
		i.show();
		

	}
	

}
