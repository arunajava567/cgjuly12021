package com.cg.pms;
public class Product {
	int id;
	String name;
	int qty;
	int price;
	double totalPrice;
	//constructor   , initilizing members 
	Product() {  //empty constructor 2
		id=101;
		name="tablet";
		qty=10;
		price=9999;
	}
	Product(int id , String name) {
		this();
		this.id = id;
		this.name = name;
	}
	
	public Product(int qty, int price) {
		this(10,"Raj");  //constructor chaining  calling one constructor by the the other 
		this.qty = qty;
		this.price = price;
	}
	Product(int id, String name, int qty) {
		this.id = id;
		this.name = name;
		this.qty = qty;
	}

// parameterized constructor, construcor overloading 
	Product(int id, String name, int qty, int price) {
		//this(56,78);
		this.id=id;
		this.name=name;
		this.qty=qty;
		this.price=price;
		
	}


	void calcTotalPrice() {
		totalPrice=qty*price;
	}
	
	void dispProductDetails() {
		System.out.println(id+"  "+name+"  "+qty+   "  "+price);
		System.out.println("totalPrice:"+totalPrice);
	}

}
