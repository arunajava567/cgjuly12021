package com.cg.pms;

public class MLoad {
	//function name is same, but not signature  arguments, datatypes, number of arguments
	void area(int s ) {
		System.out.println("Area:"+(s*s));
	}
	int  area(int l , int b) {
		return (l*b);
	}
	
	void area(double  r ) {
		System.out.println("Area:"+(3.142*r*r));
	}
	public static void main(String[] args) {
		//static poly  .. compliletime
		
		MLoad m=new MLoad();
		m.area(5);
		m.area(5,6);
		m.area(5.45);
		
	}

}
