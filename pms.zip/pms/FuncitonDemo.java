package com.cg.pms;
class Products {// class bean
	private int id;
	private String name;
	Products() {
	}
	//compilation
	public Products(int id, String name) {
		this.id = id;
		this.name = name;
	}
	//runtime , accessors and mutators
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override //Object 
	public String toString() {
		return "Products [id=" + id + ", name=" + name + "]";
	}
	
	
	
	
}
public class FuncitonDemo {
	int sum(int a,int b) {
		
		return a+b;
	}
	String sayMsg(String name) {
		
		return "Good mng "+name;
	}
	//funcitons an accept object as argument
	//funciton can return an object
	Products readAndReturnProduct(Products p) {
		p.setId(101);
		p.setName("Book");
		return p;
	}
	public static void main(String[] args) {
		FuncitonDemo f=new FuncitonDemo();
		Products p=new Products();
		Products p1=f.readAndReturnProduct(p);
		System.out.println(p1); //toString(), to display content of an object 
		System.out.println(p1.id+"  "+p1.name);//not safe 
		System.out.println(p1.getId()+"  "+p1.getName());
		f.sum(4,5);
		System.out.println(f.sum(3, 4));
		System.out.println(f.sayMsg("XXXX"));
	}

}
