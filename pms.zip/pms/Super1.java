package com.cg.pms;

public class Super1 {

}
