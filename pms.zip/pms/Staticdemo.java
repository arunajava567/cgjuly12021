package com.cg.pms;

// static variables class variables  , static 



public class Staticdemo {
	
	static String country="India"; // first step in class life cycle is static variables are initialized
	
	
	static {
		System.out.println(" static block");
	}
	
   static void show() {  //static method 
		System.out.println("in show function");
	}

	public static void main(String[] args) {
		
		
		System.out.println(country); //static variables can be called directly within the same class
		System.out.println(A.x); //static variables from other classes are invoked using classname
		show();  //within same class sttaic methods are called directly 
		A.disp();
		

	}

}
