package com.cg.pms;



class Sub1 extends Super1{
	
	/*void show123() {
		System.out.println(a);
		show();
	}*/
	
}
public class AccessmodifierDemo {

	public static void main(String[] args) {
		
		Super1 s=new Super1();
		s.
		
		/*System.out.println(s.a);
		s.show();*/
		

	}

}
