package com.cg.pms;
public class A{
	public static int x=99;
	public static int y=77;
	
	static void disp() {
		
	}
}