package com.cg.pms;

//java.lang.Object
// equals() => string content , object object equality
//hashCode()
//toString()
//finalize()
// wait (), notify() notifyAll()
//clone()


class CgEmployee implements Cloneable {
	
	int id;
	String name;
	String dep;
	CgEmployee() {
		
	}
	public CgEmployee(int id, String name, String dep) {
		super();
		this.id = id;
		this.name = name;
		this.dep = dep;
	}
	@Override
	public String toString() {
		return "CgEmployee [id=" + id + ", name=" + name + ", dep=" + dep + "]";
	}
	// need not be implemented and called
	public void finalize() {
		id=0;
		name=null;
		dep=null;
	}
	
	
	public Object clone()  throws CloneNotSupportedException{
		
		return super.clone();
	}
	
	
	
	
}
public class Objectdemo {

	public static void main(String[] args) throws CloneNotSupportedException
	{
		CgEmployee c1= new CgEmployee();
		CgEmployee c2= new CgEmployee();
		System.out.println(c1+"  "+c2);
		System.out.println(c1.equals(c2));
		CgEmployee c3=c2;
		System.out.println(c3.equals(c2));
		System.out.println(c1.hashCode());
		CgEmployee cg1=new CgEmployee(20,"ram","IT");
		System.out.println(cg1);
		
		CgEmployee cg2=(CgEmployee)cg1.clone();
		System.out.println("Before cloning "+cg1+" after cloning   "+cg2);
		System.out.println(cg2.getClass());
		
	}

}
