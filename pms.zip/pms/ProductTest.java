package com.cg.pms;

public class ProductTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int x=10; //local 
		
		Product p=new Product(); //1 default JVM
		p.calcTotalPrice();
		p.dispProductDetails();
		Product p1=new Product(102,"Laptop",20,99999);//parameter, arguments or local variable 
		p1.calcTotalPrice();
		p1.dispProductDetails();
		Product p2=new Product(103,"book");
		p2.calcTotalPrice();
		p2.dispProductDetails();
		
		Product p3=new Product(89,7898);
		p3.dispProductDetails();
		System.out.println(Product.mname); //static 
		System.gc();//GC
		
	}

}
