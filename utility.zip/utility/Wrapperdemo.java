package utility;

public class Wrapperdemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//byte, short,iunt,float,long,double ,char,boolean
		//Object
		
		
		int a=10;
		
		//boxing, autoboxing
		Integer aObj=new Integer(10);//primitive to Object
		
		//UnBoxing, autoUnboxing 
		int aObjval=aObj.intValue(); //Object to value
		
		
		
		byte b=45;
		
		Byte bObj=new Byte(b);
		
		byte bObjval=bObj.byteValue();
		
		
		String age="30";    //"CG2021ram90"  -> "90" ->
		
		int age1=Integer.parseInt(age); //string to int
		
		String stingage=aObj.toString();  //Int object to string 
		
		double age2=Double.parseDouble(age);
		
		long age3=Long.parseLong(age);
		
		float age4=Float.parseFloat(age);
		
		int x=90;
		
		double x1=x;  //implicit, lower to higher , widening,
		
		int x2=(int)x1; // explicit, narrowing
		
		Vehicle v=new Vehicle();
		
		Car c=new Car();
		
		Object o=c;
		Object o1=v;
		
		
		v=c;//implicit
		
		c=(Car)v;//explicit
		
		System.out.println(System.currentTimeMillis());
		
		System.gc();
		
		System.exit(1);
		

	}

}


class Vehicle{
}
class Car extends Vehicle{
	
}

