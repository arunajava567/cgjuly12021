package utility;
//import java.lang.*;

public class StringDemo {

	public static void main(String[] args) {
		//immutable, create duplicates, useful to store pin password
		//literal
		String name="CGemployee";
		//string object
		String name1=new String("CGemployee1");
		System.out.println(name1.charAt(2));
		System.out.println(name1.toLowerCase());
		System.out.println(name1.startsWith("C"));
		System.out.println(name1.endsWith("e"));
		System.out.println(name1.indexOf("o"));
		System.out.println(name1.lastIndexOf("o"));
		String tokens[]=name.split("-");
		System.out.println(name1.concat(name));
		System.out.println(name1.substring(3,5));
		System.out.println(name1.replace("e","a"));
		System.out.println(name1.equals(name));
		
		//mutable, will not create duplicates
		StringBuffer sb2=new StringBuffer(name1);  //string to stringbuffer
		
		StringBuffer sb1=new StringBuffer("Capgemini");
		System.out.println(sb1.length());
		System.out.println(sb1.capacity());
		sb1.ensureCapacity(100);
		System.out.println(sb1.capacity());
		
		System.out.println(sb1.insert(2, "XXXX"));
		
		System.out.println(sb1.delete(2, 6));
		System.out.println(sb1.append("Technologies"));
		System.out.println(sb1.reverse());
		
		//String buffer is syncronized, lock n unlock slow
		
		StringBuilder sb3=new StringBuilder("Capgemini");
		//faster than stringbuffer ,mutable , not create duplicates
		
		StringBuilder sb4=new StringBuilder(name1);
		
		String ss1=sb4.toString();
		String ss2=sb2.toString();
		
		

		
		
		
		
		
		
		

	}

}
